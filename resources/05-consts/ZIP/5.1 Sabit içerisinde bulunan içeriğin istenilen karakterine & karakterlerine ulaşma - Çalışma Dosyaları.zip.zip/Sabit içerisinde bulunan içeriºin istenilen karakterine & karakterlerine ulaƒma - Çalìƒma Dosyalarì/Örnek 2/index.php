<!doctype html>
<html lang="tr-TR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="tr">
<meta charset="utf-8">
<title>Extra Eğitim</title>
</head>

<body>
	<?php
	
	const ISIMSOYISIM	=	"Volkan Alakent";
	
	echo ISIMSOYISIM[0] . "<br />";
	echo ISIMSOYISIM[1] . "<br />";
	echo ISIMSOYISIM[2] . "<br />";
	echo ISIMSOYISIM[3] . "<br />";
	echo ISIMSOYISIM[4] . "<br />";
	echo ISIMSOYISIM[5] . "<br />";
	echo ISIMSOYISIM[6] . "<br />";
	echo ISIMSOYISIM[7] . "<br />";
	echo ISIMSOYISIM[8] . "<br />";
	echo ISIMSOYISIM[9] . "<br />";
	echo ISIMSOYISIM[10] . "<br />";
	echo ISIMSOYISIM[11] . "<br />";
	echo ISIMSOYISIM[12] . "<br />";
	echo ISIMSOYISIM[13];
	
	?>
</body>
</html>