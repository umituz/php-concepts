<!doctype html>
<html lang="tr-TR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="tr">
<meta charset="utf-8">
<title>Extra Eğitim</title>
</head>

<body>
	<form action="sonuc.php" method="post">
		İsim : <input type="text" name="KullaniciAdi"><br />
		Soyisim : <input type="text" name="KullaniciSoyadi"><br />
		<input type="submit" value="Bilgileri Gönder">
	</form>
</body>
</html>