<!doctype html>
<html lang="tr-TR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="tr">
<meta charset="utf-8">
<title>Extra Eğitim</title>
</head>

<body>
	<?php
	/*
	$_SERVER	:	Http (Hyper Text Transfer Protocol) (hiper metin transferi protokolü) server’ı (sunucusu) tarafından oluşturulan, server (sunucu) ve işletme ortamı bilgilerine ulaşılabilme imkanı tanır. Fakat her Http (Hyper Text Transfer Protocol) (hiper metin transferi protokolü) server’ı (sunucusu) bu değerleri oluşturacak diye bir garanti yoktur. Ayrıca her Http (Hyper Text Transfer Protocol) (hiper metin transferi protokolü) server’ı (sunucusu) farkı değerler üretebilir.
	*/
	
	echo "<pre>";
	print_r($_SERVER);
	echo "</pre>";
	
	?>
</body>
</html>