<!doctype html>
<html lang="tr-TR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="tr">
<meta charset="utf-8">
<title>Extra Eğitim</title>
</head>

<body>
	<?php
	/*
	strftime()		:	Yerel tarih ve saat bilgilerini belirtilecek olan formata göre biçimlendirerek, biçimlendirdiği değeri geriye döndürür.
	strtotime()		:	İngilizce metin içerikli bir zamanın Unix zaman damgası değerini bularak, bulduğu değeri geriye döndürür.
	*/
	
	$Zaman				=	date("Y-m-d");
	
	$ZamanDamgasiBir	=	strtotime($Zaman);
	
	$ZamanDamgasiIki	=	strtotime("1 day", $ZamanDamgasiBir);
	
	echo "Tarih : " . $Zaman . "<br />";
	echo "Zamandamgasi 1 : " . $ZamanDamgasiBir . "<br />";
	echo "Zamandamgasi 2 : " . $ZamanDamgasiIki;
	
	?>
</body>
</html>