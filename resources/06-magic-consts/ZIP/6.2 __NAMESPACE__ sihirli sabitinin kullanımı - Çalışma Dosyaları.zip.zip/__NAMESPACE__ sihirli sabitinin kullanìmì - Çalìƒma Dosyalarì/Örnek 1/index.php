<?php
	namespace DenemeProjesi;
?>
<!doctype html>
<html lang="tr-TR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="tr">
<meta charset="utf-8">
<title>Extra Eğitim</title>
</head>

<body>
	<?php
	/*
	__NAMESPACE__	:	PHP (Hypertext Preprocessor) (üstün yazı ön işlemcisi) (Personal Home Page) (kişisel ana sayfa) dosyası içerisinde tanımlanmış olan namespace’ın (isim uzayının), namespace (isim uzayı) adı bilgisi değerini döndürür.
	*/
	
	echo __NAMESPACE__;
	
	?>
</body>
</html>