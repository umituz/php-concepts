<!doctype html>
<html lang="tr-TR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="tr">
<meta charset="utf-8">
<title>Extra Eğitim</title>
</head>

<body>
	<?php
	
	$Deger		=	"Volkan";
	$$Deger		=	"Alakent";
	
	echo $Deger;
	echo "<br />";
	echo $$Deger;
	
	?>
</body>
</html>