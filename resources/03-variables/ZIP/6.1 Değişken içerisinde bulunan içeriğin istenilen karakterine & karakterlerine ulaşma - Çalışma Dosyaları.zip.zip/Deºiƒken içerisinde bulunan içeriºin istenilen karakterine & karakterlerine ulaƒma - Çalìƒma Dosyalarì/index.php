<!doctype html>
<html lang="tr-TR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="tr">
<meta charset="utf-8">
<title>Extra Eğitim</title>
</head>

<body>
	<?php
	
	$IsimSoyisim	=	"Volkan Alakent";
	
	echo $IsimSoyisim[0] . "<br />";
	echo $IsimSoyisim[1] . "<br />";
	echo $IsimSoyisim[2] . "<br />";
	echo $IsimSoyisim[3] . "<br />";
	echo $IsimSoyisim[4] . "<br />";
	echo $IsimSoyisim[5] . "<br />";
	echo $IsimSoyisim[6] . "<br />";
	echo $IsimSoyisim[7] . "<br />";
	echo $IsimSoyisim[8] . "<br />";
	echo $IsimSoyisim[9] . "<br />";
	echo $IsimSoyisim[10] . "<br />";
	echo $IsimSoyisim[11] . "<br />";
	echo $IsimSoyisim[12] . "<br />";
	echo $IsimSoyisim[13] . "<br />";
	
	?>
</body>
</html>