<!doctype html>
<html lang="tr-TR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="tr">
<meta charset="utf-8">
<title>Extra Eğitim</title>
</head>

<body>
	<?php
	/*
	pi()	:	PI sayısı değerini geriye döndürür.
	M_PI	:	PI sayısı değerini geriye döndürür.
	*/
	
	$PiSayisiDegeriA	=	pi();
	$PiSayisiDegeriB	=	M_PI;
	
	echo 'pi() metodu kullanılarak üretilen pi sayısı değeri : ' . $PiSayisiDegeriA . "<br />";
	echo 'M_PI metodu kullanılarak üretilen pi sayısı değeri : ' . $PiSayisiDegeriB;
	
	?>
</body>
</html>