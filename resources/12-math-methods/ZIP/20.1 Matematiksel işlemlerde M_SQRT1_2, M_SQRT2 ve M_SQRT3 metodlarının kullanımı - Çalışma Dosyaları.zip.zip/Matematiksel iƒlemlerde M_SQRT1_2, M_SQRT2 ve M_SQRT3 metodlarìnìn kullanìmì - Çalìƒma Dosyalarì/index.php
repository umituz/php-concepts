<!doctype html>
<html lang="tr-TR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="tr">
<meta charset="utf-8">
<title>Extra Eğitim</title>
</head>

<body>
	<?php
	/*
	M_SQRT1_2		:	1/2 Sayısının karekök değerini geriye döndürür.
	M_SQRT2			:	2 Sayısının karekök değerini geriye döndürür.
	M_SQRT3			:	3 Sayısının karekök değerini geriye döndürür.
	*/
	
	$DegerBir		=	M_SQRT1_2;
	$DegerIki		=	M_SQRT2;
	$DegerUc		=	M_SQRT3;
	
	echo "1/2 Sayısının karekök değeri : " . $DegerBir . "<br />";
	echo "2 Sayısının karekök değeri : " . $DegerIki . "<br />";
	echo "3 Sayısının karekök değeri : " . $DegerUc;
	
	?>
</body>
</html>