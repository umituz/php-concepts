<!doctype html>
<html lang="tr-TR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="tr">
<meta charset="utf-8">
<title>Extra Eğitim</title>
</head>

<body>
	<?php
	/*
	M_1_PI		:	1/PI sayısının değerini geriye döndürür.
	M_2_PI		:	2/PI sayısının değerini geriye döndürür.
	M_PI_2		:	PI/2 sayısının değerini geriye döndürür.
	M_PI_4		:	PI/4 sayısının değerini geriye döndürür.
	*/
	
	$Deger		=	M_PI_4;
	
	echo "PI/4 sayısının değeri : " . $Deger;
	
	?>
</body>
</html>