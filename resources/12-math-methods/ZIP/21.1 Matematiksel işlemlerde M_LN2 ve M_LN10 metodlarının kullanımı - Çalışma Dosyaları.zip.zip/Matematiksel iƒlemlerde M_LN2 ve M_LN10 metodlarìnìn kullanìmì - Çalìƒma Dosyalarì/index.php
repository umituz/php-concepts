<!doctype html>
<html lang="tr-TR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="tr">
<meta charset="utf-8">
<title>Extra Eğitim</title>
</head>

<body>
	<?php
	/*
	M_LN2		:	2 Sayısının doğal logaritması değerini elde etmek için kullanılır.
	M_LN10		:	10 Sayısının doğal logaritması değerini elde etmek için kullanılır.
	*/
	
	$DegerBir	=	M_LN2;
	$DegerIki	=	M_LN10;
	
	echo "2 Sayısının doğal logaritma değeri : " . $DegerBir . "<br />";
	echo "10 Sayısının doğal logaritma değeri : " . $DegerIki;
	
	?>
</body>
</html>