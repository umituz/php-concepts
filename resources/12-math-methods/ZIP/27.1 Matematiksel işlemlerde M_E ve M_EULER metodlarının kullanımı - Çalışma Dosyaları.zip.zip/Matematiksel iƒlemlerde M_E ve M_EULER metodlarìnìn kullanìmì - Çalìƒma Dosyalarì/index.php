<!doctype html>
<html lang="tr-TR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="tr">
<meta charset="utf-8">
<title>Extra Eğitim</title>
</head>

<body>
	<?php
	/*
	M_E			:	Euler sayısı değerini geriye döndürür.
	M_EULER		:	Euler sabiti değerini geriye döndürür.
	*/
	
	$DegerBir		=	M_E;
	$DegerIki		=	M_EULER;
	
	echo "Euler sayısı değeri : " . $DegerBir . "<br />";
	echo "Euler sabiti değeri : " . $DegerIki;
	
	?>
</body>
</html>