<!doctype html>
<html lang="tr-TR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="tr">
<meta charset="utf-8">
<title>Extra Eğitim</title>
</head>

<body>
	<?php
	/*
	log()		:	Herhangi bir sayının doğal logaritmasını bularak, bulduğu değeri geriye döndürür.
	log10()		:	Herhangi bir sayının 10'luk tabana (base-10) göre doğal logaritmasını bularak, bulduğu değeri geriye döndürür.
	*/
	
	$Sayi		=	8;
	
	$Sonuc		=	log10($Sayi);
	
	echo $Sayi . " Sayısının 10'luk tabana (base-10) göre doğal logaritması : " . $Sonuc;
	
	?>
</body>
</html>