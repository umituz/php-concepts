<!doctype html>
<html lang="tr-TR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="tr">
<meta charset="utf-8">
<title>Extra Eğitim</title>
</head>

<body>
	<?php
	/*
	pow()	:	Herhangi bir sayının belirtilecek değer kadar üssünü bularak, bulduğu değeri geriye döndürür.
	*/
	
	$Deger1		=	5;
	$Deger2		=	4;
	
	$SayiUssu	=	pow($Deger1, $Deger2);
	
	echo $Deger1 . " üssü " . $Deger2 . " = " . $SayiUssu;

	?>
</body>
</html>