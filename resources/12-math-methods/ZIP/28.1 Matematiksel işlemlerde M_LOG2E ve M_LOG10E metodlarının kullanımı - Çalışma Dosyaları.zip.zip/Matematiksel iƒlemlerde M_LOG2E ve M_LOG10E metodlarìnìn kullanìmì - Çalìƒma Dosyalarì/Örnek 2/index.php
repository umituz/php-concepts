<!doctype html>
<html lang="tr-TR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="tr">
<meta charset="utf-8">
<title>Extra Eğitim</title>
</head>

<body>
	<?php
	/*
	M_LOG2E		:	Euler sayısının 2 tabanına göre logaritmik değerini geriye döndürür.
	M_LOG10E	:	Euler sayısının 10 tabanına göre logaritmik değerini geriye döndürür.
	*/
	
	$Deger		=	M_LOG10E;
	
	echo "Euler sayısının 10 tabanına göre logaritmik değeri : " . $Deger;
	
	?>
</body>
</html>