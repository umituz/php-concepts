function Deneme(){
	document.getElementById("IslemAlani").innerHTML = "Extra Eğitim";
}