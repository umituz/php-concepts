<!doctype html>
<html lang="tr-TR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="tr">
<meta charset="utf-8">	
<title>Extra Eğitim</title>
<link type="text/css" rel="stylesheet" href="Sitil.css">
<script type="text/javascript" language="javascript" src="Javascript.js"></script>
</head>

<body>
<?php
	echo "Volkan Alakent<br /><br />";
?>
<input type="button" onClick="Deneme();" value="İşlem Yap"><br /><br />
<div id="IslemAlani"></div>
</body>
</html>