<!doctype html>
<html lang="tr-TR">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="tr">
<meta charset="utf-8">
<title>Extra Eğitim</title>
</head>

<body>
	<?php
	/*
	Yapısı :
	
	if(Koşul veya Koşullar):
		Kod blokları
	elseif(Koşul veya Koşullar):
		Kod blokları
	else:
		Kod blokları
	endif;
	*/
	
	if(5 < 10):
		echo "if koşulu geçerli oldu ve if kod bloğu çalıştı.";
	endif;
	
	?>
</body>
</html>